package dev.applingo;

import android.content.*;
import android.content.pm.*;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Bundle;
import android.text.*;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.*;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.*;
import androidx.transition.TransitionManager;
import com.google.android.material.bottomsheet.*;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.chip.Chip;
import com.google.android.material.color.MaterialColors;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.*;
import com.google.android.material.transition.MaterialFadeThrough;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends AppCompatActivity {
    private AccessModel access;
    private FrameLayout root;
    private View setup,home;
    private MaterialCardView rootCard,shizukuCard;
    private MaterialButton allow,openShizuku,statusButton;
    private TextView accessMessage,count,empty;
    private TextInputEditText search;
    private Chip allApps;
    private View accessProgress,actionProgress;
    private RecyclerView appList;
    private final ArrayList<AppEntry> apps=new ArrayList<>(),shown=new ArrayList<>();
    private final Map<String,String> knownLocales=new HashMap<>();
    private final ExecutorService loader=Executors.newSingleThreadExecutor();
    private final AppAdapter adapter=new AppAdapter();
    private boolean loading=true,busy,firstResume=true;
    private BottomSheetDialog activeSheet;

    @Override public void onCreate(Bundle saved){
        super.onCreate(saved);
        WindowCompat.setDecorFitsSystemWindows(getWindow(),false);
        boolean light=(getResources().getConfiguration().uiMode&Configuration.UI_MODE_NIGHT_MASK)!=Configuration.UI_MODE_NIGHT_YES;
        WindowInsetsControllerCompat insets=new WindowInsetsControllerCompat(getWindow(),getWindow().getDecorView());
        insets.setAppearanceLightStatusBars(light);insets.setAppearanceLightNavigationBars(light);
        getWindow().setStatusBarColor(Color.TRANSPARENT);getWindow().setNavigationBarColor(Color.TRANSPARENT);
        root=new FrameLayout(this);root.setBackgroundColor(color(com.google.android.material.R.attr.colorSurface));setContentView(root);
        ViewCompat.setOnApplyWindowInsetsListener(root,(v,i)->{androidx.core.graphics.Insets b=i.getInsets(WindowInsetsCompat.Type.systemBars()|WindowInsetsCompat.Type.ime());v.setPadding(b.left,b.top,b.right,b.bottom);return i;});
        setup=getLayoutInflater().inflate(R.layout.screen_setup,root,false);home=getLayoutInflater().inflate(R.layout.screen_home,root,false);
        root.addView(home);root.addView(setup);home.setVisibility(View.GONE);
        rootCard=findViewById(R.id.choose_root);shizukuCard=findViewById(R.id.choose_shizuku);
        allow=findViewById(R.id.allow_access);openShizuku=findViewById(R.id.open_shizuku);accessMessage=findViewById(R.id.access_message);accessProgress=findViewById(R.id.access_progress);
        statusButton=findViewById(R.id.access_status);search=findViewById(R.id.search_apps);allApps=findViewById(R.id.show_all);count=findViewById(R.id.app_count);empty=findViewById(R.id.empty_apps);actionProgress=findViewById(R.id.action_progress);appList=findViewById(R.id.app_list);
        appList.setLayoutManager(new LinearLayoutManager(this));appList.setAdapter(adapter);
        access=new ViewModelProvider(this).get(AccessModel.class);
        rootCard.setOnClickListener(v->access.select(AccessGate.Mode.ROOT));shizukuCard.setOnClickListener(v->access.select(AccessGate.Mode.SHIZUKU));
        allow.setOnClickListener(v->access.connect(true));openShizuku.setOnClickListener(v->openShizuku());
        findViewById(R.id.setup_help).setOnClickListener(v->help());findViewById(R.id.about).setOnClickListener(v->help());
        statusButton.setOnClickListener(v->{if(!busy)new MaterialAlertDialogBuilder(this).setTitle("Connection")
            .setMessage("AppLingo is connected through "+(access.snapshot().mode==AccessGate.Mode.ROOT?"Root":"Shizuku")+". Access is checked again when you return to the app.")
            .setPositiveButton("Done",null).setNeutralButton("Change access method",(d,w)->access.setup()).show();});
        search.addTextChangedListener(watcher(this::filter));allApps.setOnCheckedChangeListener((b,c)->filter());
        access.state().observe(this,this::renderAccess);access.start();loadApps();
    }
    @Override protected void onResume(){super.onResume();refreshPhoneLanguage();if(access!=null){if(firstResume)firstResume=false;else access.resume();}}
    private String phoneLanguage(){
        return PhoneLanguages.describe(getSystemService(android.app.LocaleManager.class).getSystemLocales(),Locale.getDefault());
    }
    private String followSystem(){return getString(R.string.follow_system_language,phoneLanguage());}
    private void refreshPhoneLanguage(){
        if(home==null||setup==null)return;
        String text=getString(R.string.phone_language,phoneLanguage());
        ((TextView)home.findViewById(R.id.phone_language_home)).setText(text);
        ((TextView)setup.findViewById(R.id.phone_language_setup)).setText(text);
        adapter.notifyDataSetChanged();
    }
    void renderAccess(AccessGate.Snapshot state){
        boolean ready=state.phase==AccessGate.Phase.READY;
        if(!ready&&activeSheet!=null){activeSheet.dismiss();activeSheet=null;}
        if(root.isLaidOut()&&home.getVisibility()!=(ready?View.VISIBLE:View.GONE)){
            MaterialFadeThrough fade=new MaterialFadeThrough();fade.setDuration(220);TransitionManager.beginDelayedTransition(root,fade);
        }
        home.setVisibility(ready?View.VISIBLE:View.GONE);setup.setVisibility(ready?View.GONE:View.VISIBLE);
        if(ready){statusButton.setText(state.message);return;}
        boolean checking=state.phase==AccessGate.Phase.CHECKING,isRoot=state.mode==AccessGate.Mode.ROOT;
        styleAccessCard(rootCard,isRoot);styleAccessCard(shizukuCard,!isRoot);
        rootCard.setEnabled(!checking);shizukuCard.setEnabled(!checking);allow.setEnabled(!checking);
        accessMessage.setText(state.message);accessProgress.setVisibility(checking?View.VISIBLE:View.GONE);
        allow.setText(checking?R.string.checking:isRoot?R.string.allow_root:R.string.allow_shizuku);
        openShizuku.setVisibility(isRoot?View.GONE:View.VISIBLE);openShizuku.setEnabled(!checking);
    }
    private void styleAccessCard(MaterialCardView card,boolean selected){
        card.setCheckable(true);card.setChecked(selected);card.setStrokeWidth(dp(selected?2:1));
        card.setStrokeColor(color(selected?androidx.appcompat.R.attr.colorPrimary:com.google.android.material.R.attr.colorOutlineVariant));
        card.setCardBackgroundColor(color(selected?com.google.android.material.R.attr.colorPrimaryContainer:com.google.android.material.R.attr.colorSurfaceContainerLow));
        int foreground=color(selected?com.google.android.material.R.attr.colorOnPrimaryContainer:com.google.android.material.R.attr.colorOnSurface);
        card.setCheckedIconTint(android.content.res.ColorStateList.valueOf(foreground));
        tintCard(card,foreground);
    }
    private void tintCard(ViewGroup group,int foreground){
        for(int i=0;i<group.getChildCount();i++){
            View child=group.getChildAt(i);
            if(child instanceof TextView)((TextView)child).setTextColor(foreground);
            else if(child instanceof ImageView)((ImageView)child).setImageTintList(android.content.res.ColorStateList.valueOf(foreground));
            else if(child instanceof ViewGroup)tintCard((ViewGroup)child,foreground);
        }
    }
    private void openShizuku(){
        Intent launch=getPackageManager().getLaunchIntentForPackage("moe.shizuku.privileged.api");
        if(launch!=null){try{startActivity(launch);}catch(Exception e){error("Couldn’t open Shizuku",e.getMessage());}}
        else new MaterialAlertDialogBuilder(this).setTitle("Get Shizuku").setMessage("Install Shizuku, follow its wireless debugging setup, then return here and allow access.")
            .setPositiveButton("Open setup guide",(d,w)->openUrl("https://shizuku.rikka.app/guide/setup/")).setNegativeButton(R.string.cancel,null).show();
    }
    private void help(){new MaterialAlertDialogBuilder(this).setTitle("AppLingo 1.2")
        .setMessage("Choose Root if your phone is rooted. Otherwise, install and start Shizuku using wireless debugging, then allow AppLingo access.\n\nPick an app, choose a language, and apply. Follow system removes that app’s language override.\n\nAndroid 13+ is required. AppLingo can request languages for apps outside Android’s language picker, but cannot add missing translations or override an app’s own language logic.\n\nChanges apply only to this Android profile. No app data is read or cleared. There are no ads, analytics or internet permission. Language overrides remain after uninstalling AppLingo.\n\nBuilt with Material 3 Expressive, AndroidX and Shizuku API. Open-source notices are included with the app.")
        .setPositiveButton(R.string.done,null).setNeutralButton(R.string.setup_help,(d,w)->openUrl("https://shizuku.rikka.app/guide/setup/")).show();}
    private void openUrl(String url){try{startActivity(new Intent(Intent.ACTION_VIEW,android.net.Uri.parse(url)));}catch(Exception e){error("No browser available","Install a browser to open the setup guide.");}}
    private void loadApps(){
        loader.execute(()->{
            ArrayList<AppEntry> found=new ArrayList<>();
            try{
                PackageManager pm=getPackageManager();
                for(ApplicationInfo info:pm.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(0))){
                    if(!info.packageName.equals(getPackageName()))found.add(new AppEntry(info.packageName,info.loadLabel(pm).toString(),pm.getLaunchIntentForPackage(info.packageName)!=null,info));
                }
                found.sort(Comparator.comparing(a->a.label.toLowerCase(Locale.ROOT)));
                runOnUiThread(()->{if(isDestroyed())return;apps.clear();apps.addAll(found);loading=false;filter();});
            }catch(Exception e){runOnUiThread(()->{if(isDestroyed())return;loading=false;count.setText("Couldn’t load apps");empty.setText("Close and reopen AppLingo to try again.");empty.setVisibility(View.VISIBLE);});}
        });
    }
    private void filter(){
        if(search==null)return;String q=search.getText()==null?"":search.getText().toString().trim().toLowerCase(Locale.ROOT);shown.clear();
        for(AppEntry app:apps)if((allApps.isChecked()||app.launchable)&&(app.label.toLowerCase(Locale.ROOT).contains(q)||app.pkg.toLowerCase(Locale.ROOT).contains(q)))shown.add(app);
        adapter.notifyDataSetChanged();count.setText(loading?getString(R.string.loading_apps):getResources().getQuantityString(R.plurals.app_count,shown.size(),shown.size()));
        empty.setVisibility(!loading&&shown.isEmpty()?View.VISIBLE:View.GONE);
    }
    private void selectApp(AppEntry app){
        if(busy||access.snapshot().phase!=AccessGate.Phase.READY)return;hideKeyboard();setBusy(true);
        access.locale(app.pkg,"",false,new AccessModel.Callback(){
            public void done(String value){if(isDestroyed())return;setBusy(false);knownLocales.put(app.pkg,value);adapter.notifyDataSetChanged();edit(app,value);}
            public void failed(String message){if(isDestroyed())return;setBusy(false);error("Couldn’t read language",message);}
        });
    }
    private void edit(AppEntry app,String current){
        BottomSheetDialog sheet=new BottomSheetDialog(this);activeSheet=sheet;
        sheet.setOnDismissListener(d->{if(activeSheet==sheet)activeSheet=null;});
        LinearLayout content=sheetContent();
        ImageView icon=new ImageView(this);icon.setImageDrawable(app.info.loadIcon(getPackageManager()));LinearLayout.LayoutParams iconSize=new LinearLayout.LayoutParams(dp(56),dp(56));iconSize.bottomMargin=dp(12);content.addView(icon,iconSize);
        content.addView(label(app.label,com.google.android.material.R.attr.textAppearanceHeadlineMedium));
        TextView pkg=label(app.pkg,com.google.android.material.R.attr.textAppearanceBodySmall);pkg.setTextColor(color(com.google.android.material.R.attr.colorOnSurfaceVariant));content.addView(pkg);
        TextView currentText=label(getString(R.string.current_language,current.isEmpty()?followSystem():display(current)),com.google.android.material.R.attr.textAppearanceBodyMedium);space(currentText,16,12);content.addView(currentText);
        final String[] selected={current};
        MaterialButton choice=button(current.isEmpty()?getString(R.string.choose_language):display(current),false);choice.setIconResource(R.drawable.ic_chevron);choice.setIconGravity(MaterialButton.ICON_GRAVITY_TEXT_END);content.addView(choice,full());
        choice.setOnClickListener(v->languagePicker(tag->{selected[0]=tag;choice.setText(display(tag));},sheet));
        MaterialButton custom=new MaterialButton(this,null,androidx.appcompat.R.attr.borderlessButtonStyle);custom.setText(R.string.custom_tag);custom.setMinHeight(dp(52));content.addView(custom,full());
        custom.setOnClickListener(v->customTag(tag->{selected[0]=tag;choice.setText(display(tag));}));
        TextView note=label(getString(R.string.language_note),com.google.android.material.R.attr.textAppearanceBodyMedium);space(note,8,16);content.addView(note);
        MaterialButton apply=button(getString(R.string.apply),true);apply.setMinHeight(dp(60));content.addView(apply,full());
        apply.setOnClickListener(v->{if(selected[0].isEmpty()){choice.setError("Choose a language first");return;}sheet.dismiss();activeSheet=null;apply(app,selected[0]);});
        MaterialButton reset=button(followSystem(),false);content.addView(reset,full());reset.setOnClickListener(v->{sheet.dismiss();activeSheet=null;apply(app,"");});
        ScrollView scroll=new ScrollView(this);scroll.addView(content);sheet.setContentView(scroll);showSheet(sheet);
    }
    private interface Choice{void accept(String tag);}
    private void customTag(Choice choice){
        TextInputLayout field=new TextInputLayout(this,null,com.google.android.material.R.attr.textInputOutlinedStyle);field.setHint(R.string.custom_tag);field.setHelperText(getString(R.string.custom_tag_hint));
        TextInputEditText input=new TextInputEditText(field.getContext());input.setSingleLine(true);input.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);field.addView(input);
        LinearLayout box=new LinearLayout(this);box.setPadding(dp(24),dp(12),dp(24),0);box.addView(field,full());
        androidx.appcompat.app.AlertDialog dialog=new MaterialAlertDialogBuilder(this).setTitle(R.string.custom_tag_title).setView(box).setNegativeButton(R.string.cancel,null).setPositiveButton(R.string.use_tag,null).create();
        dialog.setOnShowListener(d->dialog.getButton(android.content.DialogInterface.BUTTON_POSITIVE).setOnClickListener(v->{
            try{String tag=LocaleCommands.normalize(input.getText()==null?"":input.getText().toString().trim());if(tag.isEmpty())throw new IllegalArgumentException("Enter a language tag.");choice.accept(tag);dialog.dismiss();}
            catch(Exception e){field.setError(e.getMessage());}
        }));dialog.show();
    }
    private void languagePicker(Choice callback,BottomSheetDialog parent){
        LinkedHashMap<String,String> options=new LinkedHashMap<>();
        for(String tag:new String[]{"en","en-GB","zh-Hant-HK","zh-Hant-TW","zh-Hans-CN","ja","ko","fr","de","es","pt-BR","ar","hi","id","th","vi"})options.put(tag,display(tag));
        ArrayList<Locale> locales=new ArrayList<>(Arrays.asList(Locale.getAvailableLocales()));locales.sort(Comparator.comparing(l->l.getDisplayName(Locale.getDefault())));
        for(Locale locale:locales)if(!locale.getLanguage().isEmpty()&&!"und".equals(locale.toLanguageTag()))options.putIfAbsent(locale.toLanguageTag(),display(locale.toLanguageTag()));
        BottomSheetDialog sheet=new BottomSheetDialog(this);activeSheet=sheet;
        LinearLayout content=sheetContent();content.addView(label(getString(R.string.choose_language),com.google.android.material.R.attr.textAppearanceHeadlineMedium));
        TextInputLayout field=new TextInputLayout(this,null,com.google.android.material.R.attr.textInputOutlinedStyle);field.setHint(R.string.search_languages);field.setStartIconDrawable(R.drawable.ic_search);field.setEndIconMode(TextInputLayout.END_ICON_CLEAR_TEXT);
        TextInputEditText query=new TextInputEditText(field.getContext());query.setSingleLine(true);field.addView(query);space(field,16,8);content.addView(field,full());
        ListView list=new ListView(this);list.setDividerHeight(0);int height=Math.max(dp(160),(int)(getResources().getDisplayMetrics().heightPixels*.46));content.addView(list,new LinearLayout.LayoutParams(-1,height));
        ArrayList<String> tags=new ArrayList<>(),labels=new ArrayList<>();ArrayAdapter<String> choices=new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,labels);list.setAdapter(choices);
        Runnable update=()->{String q=query.getText()==null?"":query.getText().toString().toLowerCase(Locale.ROOT);tags.clear();labels.clear();for(Map.Entry<String,String> entry:options.entrySet())if(entry.getValue().toLowerCase(Locale.ROOT).contains(q)){tags.add(entry.getKey());labels.add(entry.getValue());}choices.notifyDataSetChanged();};
        query.addTextChangedListener(watcher(update));update.run();list.setOnItemClickListener((p,v,pos,id)->{callback.accept(tags.get(pos));sheet.dismiss();});
        sheet.setOnDismissListener(d->{activeSheet=parent;if(access.snapshot().phase!=AccessGate.Phase.READY)parent.dismiss();});
        sheet.setContentView(content);showSheet(sheet);
    }
    private void apply(AppEntry app,String tag){
        if(busy||access.snapshot().phase!=AccessGate.Phase.READY)return;setBusy(true);
        access.locale(app.pkg,tag,true,new AccessModel.Callback(){
            public void done(String value){if(isDestroyed())return;setBusy(false);knownLocales.put(app.pkg,value);adapter.notifyDataSetChanged();
                Snackbar bar=Snackbar.make(root,getString(R.string.language_saved),Snackbar.LENGTH_LONG);
                Intent launch=getPackageManager().getLaunchIntentForPackage(app.pkg);
                if(launch!=null)bar.setAction(R.string.open_app,v->{try{startActivity(launch);}catch(Exception e){error("Couldn’t open app",e.getMessage());}});bar.show();
            }
            public void failed(String message){if(isDestroyed())return;setBusy(false);error("Couldn’t save language",message);}
        });
    }
    private void showSheet(BottomSheetDialog sheet){
        // MaterialBackOrchestrator owns predictive progress/cancel/commit for this dialog.
        // Leave the activity's root back dispatcher unconsumed for the OS home preview.

        sheet.setOnShowListener(d->{FrameLayout frame=sheet.findViewById(com.google.android.material.R.id.design_bottom_sheet);if(frame!=null){BottomSheetBehavior<FrameLayout> b=BottomSheetBehavior.from(frame);b.setSkipCollapsed(true);b.setState(BottomSheetBehavior.STATE_EXPANDED);}});sheet.show();
    }
    private LinearLayout sheetContent(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(24),dp(28),dp(24),dp(24));return l;}
    private TextView label(String text,int appearance){TextView v=new TextView(this);android.util.TypedValue value=new android.util.TypedValue();getTheme().resolveAttribute(appearance,value,true);v.setTextAppearance(value.resourceId);v.setText(text);return v;}
    private MaterialButton button(String text,boolean filled){MaterialButton b=new MaterialButton(this,null,filled?com.google.android.material.R.attr.materialButtonStyle:com.google.android.material.R.attr.materialButtonTonalStyle);b.setText(text);b.setMinHeight(dp(52));return b;}
    private LinearLayout.LayoutParams full(){return new LinearLayout.LayoutParams(-1,-2);}
    private void space(View v,int top,int bottom){LinearLayout.LayoutParams p=full();p.topMargin=dp(top);p.bottomMargin=dp(bottom);v.setLayoutParams(p);}
    private int color(int attr){return MaterialColors.getColor(this,attr,Color.BLACK);}
    private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
    private String display(String tags){String tag=tags.split(",")[0];return Locale.forLanguageTag(tag).getDisplayName(Locale.getDefault())+" · "+tags;}
    private void setBusy(boolean value){busy=value;actionProgress.setVisibility(value?View.VISIBLE:View.GONE);statusButton.setEnabled(!value);appList.setEnabled(!value);}
    private void error(String title,String message){if(!isDestroyed())new MaterialAlertDialogBuilder(this).setTitle(title).setMessage(message==null?"Please try again.":message).setPositiveButton(R.string.done,null).show();}
    private void hideKeyboard(){((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(search.getWindowToken(),0);search.clearFocus();}
    private TextWatcher watcher(Runnable action){return new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){action.run();}public void afterTextChanged(Editable e){}};}
    static final class AppEntry{final String pkg,label;final boolean launchable;final ApplicationInfo info;AppEntry(String p,String l,boolean b,ApplicationInfo i){pkg=p;label=l;launchable=b;info=i;}}
    private static final class AppHolder extends RecyclerView.ViewHolder{final ImageView icon;final TextView title,detail;AppHolder(View v){super(v);icon=v.findViewById(R.id.app_icon);title=v.findViewById(R.id.app_label);detail=v.findViewById(R.id.app_detail);}}
    private final class AppAdapter extends RecyclerView.Adapter<AppHolder>{
        public int getItemCount(){return shown.size();}
        @Override public AppHolder onCreateViewHolder(ViewGroup parent,int type){return new AppHolder(getLayoutInflater().inflate(R.layout.item_app,parent,false));}
        @Override public void onBindViewHolder(AppHolder h,int position){AppEntry app=shown.get(position);h.icon.setImageDrawable(app.info.loadIcon(getPackageManager()));h.title.setText(app.label);String saved=knownLocales.get(app.pkg);h.detail.setText(saved==null?app.pkg:saved.isEmpty()?followSystem():display(saved));h.itemView.setOnClickListener(v->selectApp(app));}
    }
    @Override protected void onDestroy(){if(activeSheet!=null)activeSheet.dismiss();loader.shutdownNow();super.onDestroy();}
}
