# Validation — AppLingo 1.2

## Completed

- `assembleDebug`, `testDebugUnitTest` and `lintDebug` succeeded with Gradle 8.13 / AGP 8.11.1 / JDK 17.
- **29 automated tests passed**, zero failures: 10 locale-command checks, 9 access-state checks and 10 Robolectric activity/UI checks.
- Access-state checks cover initial setup, verifying without unlocking, verified readiness, denied/revoked access, stale success/failure callbacks, disconnects and delayed timeouts.
- UI checks cover initial onboarding, Root selection, disabled controls during verification, ready/lost screen transitions, light/dark/compact rendering, installed-app search and language-editor/picker inflation.
- Rendered previews reviewed for spacing, readability and contrast. Selected access-card foreground colours and custom-language button styling were corrected after review.
- Lint reported zero errors and 17 non-blocking warnings (target SDK compatibility, allocation/adapter efficiency, unused resources and configuration cleanup). The all-packages permission lint exception remains narrowly documented because the core feature manages all installed packages.
- APK signature verified; packaged manifest checked: `dev.applingo`, versionCode 3, versionName 1.2, minimum API 33, target API 35, compile API 36. No INTERNET permission.

## New behavior verified in v1.2

- Compiled manifest explicitly enables `android:enableOnBackInvokedCallback`.
- Root activity has no enabled back interceptor, leaving the system home preview available.
- Material bottom-sheet gesture progress followed by cancellation keeps both picker and editor open. Committing a subsequent gesture dismisses the picker only and restores the editor as the active sheet.
- Actual system-language preferences are displayed independently of the app-specific locale and Java default locale. Multiple languages retain their priority order, and returning to the app refreshes the labels after a system-language change.
- Both startup and home labels and Follow system details use the same system locale source.
- v1.2 signing certificate matches v1.1: SHA-256 `36641d01bf7cedfb75f62a216f8915dbf2aa00ec64664af85cfa80092487197c`. It can install over v1.1.

## Scope of UI renders

The previews in `docs/previews/` were rendered from the actual Android views using Robolectric's native graphics mode, not captured on a physical phone. Sample app rows use test-only fixture packages. Ready-state rendering is exercised with a test connection state; it is not proof of a live Shizuku/root session. Black areas outside bottom-sheet preview windows are the rendering surface, not the app's background.

## Physical-device checks still needed

No Android device was connected. Predictive gesture animation and back-to-home appearance still require physical-device testing with gesture navigation enabled. Root-manager interaction, Shizuku binding, OEM-specific locale behavior, dynamic colours on physical hardware and actual translation changes still require device testing. OnePlus/ColorOS compatibility is not claimed as tested.

First device check: grant Root or Shizuku access, select an app known to contain multiple translations, apply a language, reopen that app, then reset to Follow system. Restart AppLingo to check automatic reconnect. Stop Shizuku or revoke root access to verify the app returns to setup.

## Installation and signing

This is a debug-signed sideload build. The original v1.0 signing key was temporary and is unavailable, so v1.0 must be uninstalled before installing v1.1. Android keeps per-app locale overrides independently. The v1.1 private signing backup is stored separately and is excluded from the source ZIP and APK.
